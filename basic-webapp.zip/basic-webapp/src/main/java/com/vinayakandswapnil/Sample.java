package com.vinayakandswapnil;

import java.util.Scanner;

public class Sample {
	public static void main(String[] args) {
		// switch 



		try (Scanner s = new Scanner(System.in)) {
			System.out.println("Enter Month between(1-12) and to exit enter zero (0)");
			int month1 =0;
			String monthString = null;
			
			do {	
				month1 = s.nextInt();
				switch (month1) {
				
				case 1:
					monthString = "January";
					System.out.println(monthString);
					break;
				case 2: 
					monthString = "February";
					System.out.println(monthString);
					break;
				case 3: 
					monthString = "March";
					System.out.println(monthString);
					break;
				case 4: 
					monthString = "April";
					System.out.println(monthString);
					break;
				case 5:
					monthString = "May";
					System.out.println(monthString);
					break;
				case 6:
					monthString = "June";
					System.out.println(monthString);
					break;
				case 7:
					monthString = "July";
					System.out.println(monthString);
					break;
				case 8:
					monthString = "August";
					System.out.println(monthString);
					break;
				case 9:
					monthString = "September";
					System.out.println(monthString);
					break;
				case 10: 
					monthString = "Octomber";
					System.out.println(monthString);
					break;
				case 11: 
					monthString = "November";
					System.out.println(monthString);
					break;
				case 12: 
					monthString = "December";
					System.out.println(monthString);
					break;
				case 0: 
					System.out.println("exited");
					break;
					
				default:
					System.out.println("Enter Correct Number");
					
				}
				
				
			} while(month1!=0);
		}
		
			

	}

}
